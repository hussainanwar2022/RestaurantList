//
//  jahezdeliveryApp.swift
//  jahezdelivery
//
//  Created by Hussain Anwer on 08/02/2022.
//

import SwiftUI


struct LaunchScreenSwiftUIView: App {
    
    var body: some Scene {
        WindowGroup {
            MainContentSwiftUIView()
        }
    }
}
