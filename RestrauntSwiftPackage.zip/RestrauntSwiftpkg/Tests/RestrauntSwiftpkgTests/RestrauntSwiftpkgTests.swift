import XCTest
@testable import RestrauntSwiftpkg

final class RestrauntSwiftpkgTests: XCTestCase {
    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct
        // results.
        XCTAssertEqual(RestrauntSwiftpkg().text, "Hello, World!")
    }
}
