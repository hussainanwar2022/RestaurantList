//
//  exampleappApp.swift
//  exampleapp
//
//  Created by Capable on 10/02/2022.
//

import SwiftUI
import RestrauntSwiftpkg
@main
struct exampleappApp: App {
    var body: some Scene {
        WindowGroup {
            MainContentSwiftUIView()
        }
        
        
    }
}
